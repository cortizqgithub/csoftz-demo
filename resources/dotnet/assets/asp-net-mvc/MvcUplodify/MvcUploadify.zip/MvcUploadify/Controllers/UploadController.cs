﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;

using MvcUploadify.Models;

namespace MvcUploadify.Controllers
{
    public class UploadController : Controller
    {
        public ActionResult Index()
        {
            return RedirectToAction("Upload");
        }

        #region Upload Methods

        [HttpGet]
        public ActionResult Upload()
        {
            return View();
        }

        /// <summary>
        /// Save the posted file to the Uploads folder and return a message
        /// back to the uploadify jQuery plugin.
        /// </summary>
        /// <param name="fileData"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase fileData)
        {
            try
            {
                fileData.SaveAs(Server.MapPath("~/Uploads/") + Path.GetFileName(fileData.FileName));
            }
            catch (Exception ex)
            {
                return Content("Error uploading file: " + ex.Message);

            }

            return Content("File uploaded successfully!");
        } 
        #endregion

        #region Ajax Methods

        /// <summary>
        /// Return a list of files in the Uploads folder back 
        /// to the $.get jQuery Ajax call.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult GetPhotoList()
        {
            // Get a list of files in the Uploads folder.
            string path = Server.MapPath("~/Uploads");
            DirectoryInfo di = new DirectoryInfo(path);
            FileInfo[] files = di.GetFiles();

            // Initialize some variables.
            PhotoItem photo = null;
            List<PhotoItem> photoList = new List<PhotoItem>();

            // Loop through all the files in the Uploads folder
            // and add them to the list of PhotoItem types.
            foreach (var file in files)
            {
                photo = new PhotoItem();
                photo.FileName = Path.GetFileName(file.FullName);
                photo.Path = "/Uploads/" + Path.GetFileName(file.FullName);
                photoList.Add(photo);
            }

            // Merge the list of PhotoItem types with the UserControl
            // to render HTML and return it to the jQuery call.
            return View("ListView", photoList);
        }

        #endregion
    }
}
