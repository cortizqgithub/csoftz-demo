﻿
namespace MvcUploadify.Models
{
    public class PhotoItem
    {
        public string FileName { get; set; }
        public string Path { get; set; }
    }
}
