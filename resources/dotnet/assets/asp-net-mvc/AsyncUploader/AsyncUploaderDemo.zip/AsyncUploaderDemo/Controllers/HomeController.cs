﻿using System;
using System.Web.Mvc;
using AsyncUploaderDemo.Models;

namespace AsyncUploaderDemo.Controllers
{
    public class HomeController : Controller
    {
        // In a real app, populate this using IoC so you can mock it for tests
        private IFileStore _fileStore = new DiskFileStore();

        public  ActionResult Index() { return RedirectToAction("PersonalProfile"); }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult PersonalProfile()
        {
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult PersonalProfile(Guid? photo_guid, string photo_filename)
        {
            if (Request.Files["photo"] != null) // If uploaded synchronously
            {
                photo_guid = _fileStore.SaveUploadedFile(Request.Files["photo"]);
                photo_filename = Request.Files["photo"].FileName;
            }

            ViewData["photo_guid"] = photo_guid.Value;
            ViewData["photo_filename"] = photo_filename;
            return View("Completed");
        }

        public Guid AsyncUpload()
        {
            return _fileStore.SaveUploadedFile(Request.Files[0]);
        }
    }
}
